package com.example.pruebaapi;

public class RequestGastos {
    private RequestGastosData data;

    public RequestGastos(RequestGastosData data) {
        this.data = data;
    }

    public RequestGastosData getData() {
        return data;
    }

    public void setData(RequestGastosData data) {
        this.data = data;
    }
}
