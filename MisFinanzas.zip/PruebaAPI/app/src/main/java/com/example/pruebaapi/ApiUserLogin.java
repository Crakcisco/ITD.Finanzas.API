package com.example.pruebaapi;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiUserLogin {
    @POST("Login/Login") // Cambia esta URL al endpoint correcto para el inicio de sesión
    Call<LoginResponse> login (@Body LoginRequest loginRequest);
}