package com.example.pruebaapi;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class IngresosAdapter extends RecyclerView.Adapter<IngresosAdapter.ViewHolder> {

    private List<IngresoDto> ingresos;

    public IngresosAdapter(List<IngresoDto> ingresos) {
        this.ingresos = ingresos;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ingreso_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        IngresoDto ingreso = ingresos.get(position);
        holder.id.setText(String.valueOf(ingreso.getId()));
        holder.usuarioId.setText(String.valueOf(ingreso.getUsuarioId()));
        holder.categoriaId.setText(String.valueOf(ingreso.getCategoriaId()));
        holder.titulo.setText(ingreso.getTitulo());
        holder.cantidad.setText(String.valueOf(ingreso.getCantidad()));
        holder.fecha.setText(ingreso.getFecha());
        holder.hora.setText(ingreso.getHora());
        holder.motivo.setText(ingreso.getMotivo());
        holder.tipoIngreso.setText(ingreso.getTipoIngreso());
        holder.notas.setText(ingreso.getNotas());
    }

    @Override
    public int getItemCount() {
        return ingresos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView id;
        public TextView usuarioId;
        public TextView categoriaId;
        public TextView titulo;
        public TextView cantidad;
        public TextView fecha;
        public TextView hora;
        public TextView motivo;
        public TextView tipoIngreso;
        public TextView notas;

        public ViewHolder(View itemView) {
            super(itemView);
            id = itemView.findViewById(R.id.id);
            usuarioId = itemView.findViewById(R.id.usuario_id);
            categoriaId = itemView.findViewById(R.id.categoria_id);
            titulo = itemView.findViewById(R.id.titulo);
            cantidad = itemView.findViewById(R.id.cantidad);
            fecha = itemView.findViewById(R.id.fecha);
            hora = itemView.findViewById(R.id.hora);
            motivo = itemView.findViewById(R.id.motivo);
            tipoIngreso = itemView.findViewById(R.id.tipo_ingreso);
            notas = itemView.findViewById(R.id.notas);
        }
    }
}


