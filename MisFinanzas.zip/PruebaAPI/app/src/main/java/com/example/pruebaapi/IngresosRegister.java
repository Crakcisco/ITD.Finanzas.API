package com.example.pruebaapi;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;

public class IngresosRegister extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nuevo_ingreso);

        Button buttonAgregar = findViewById(R.id.buttonAgregar);
        buttonAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener referencias a los EditText
                EditText edtId = findViewById(R.id.id_id);
                EditText edtUsuarioId = findViewById(R.id.id_usuario_id);
                EditText edtCategoriaId = findViewById(R.id.id_categoria_id);
                EditText edtTitulo = findViewById(R.id.id_titulo);
                EditText edtCantidad = findViewById(R.id.id_cantidad);
                EditText edtFecha = findViewById(R.id.id_fecha);
                EditText edtHora = findViewById(R.id.id_hora);
                EditText edtMotivo = findViewById(R.id.id_motivo);
                EditText edtTipoIngreso = findViewById(R.id.id_tipoingreso);
                EditText edtNotas = findViewById(R.id.id_notas);

                // Obtener los valores de los EditText
                int id = Integer.parseInt(edtId.getText().toString().trim());
                int usuario_id = Integer.parseInt(edtUsuarioId.getText().toString().trim());
                int categoria_id = Integer.parseInt(edtCategoriaId.getText().toString().trim());
                String titulo = edtTitulo.getText().toString().trim();
                String cantidad = edtCantidad.getText().toString().trim();
                String fecha = edtFecha.getText().toString().trim();
                String hora = edtHora.getText().toString().trim();
                String motivo = edtMotivo.getText().toString().trim();
                String tipo_ingreso = edtTipoIngreso.getText().toString().trim();
                String notas = edtNotas.getText().toString().trim();

                // Validar que los campos no estén vacíos
                if (titulo.isEmpty() || cantidad.isEmpty() || fecha.isEmpty() || hora.isEmpty() || motivo.isEmpty() || tipo_ingreso.isEmpty() || notas.isEmpty()) {
                    Toast.makeText(IngresosRegister.this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Limpiar los campos después de validar que no estén vacíos
                clearFields(edtId, edtUsuarioId, edtCategoriaId, edtTitulo, edtCantidad, edtFecha, edtHora, edtMotivo, edtTipoIngreso, edtNotas);

                // Configurar el interceptor de logging
                HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
                logging.setLevel(HttpLoggingInterceptor.Level.BODY);

                // Configurar el cliente OkHttpClient
                OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
                httpClient.addInterceptor(logging);

                // Configurar Retrofit
                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("http://10.0.2.2:5207/api/")
                        .addConverterFactory(GsonConverterFactory.create())
                        .client(httpClient.build())
                        .build();

                // Crear la instancia de la interfaz de servicio
                ApiIngresosRegister apiIngresos = retrofit.create(ApiIngresosRegister.class);

                // Crear el objeto de datos de la solicitud
                RequestIngresosData requestIngresosData = new RequestIngresosData(id, usuario_id, categoria_id, titulo, cantidad, fecha, hora, motivo, tipo_ingreso, notas);
                RequestIngresos requestIngresos = new RequestIngresos(requestIngresosData);

                // Realizar la llamada asíncrona a la API
                Call<IngresoRegister> call = apiIngresos.registerIngreso(requestIngresos);

                // Manejar la respuesta de la llamada asíncrona
                call.enqueue(new Callback<IngresoRegister>() {
                    @Override
                    public void onResponse(Call<IngresoRegister> call, Response<IngresoRegister> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            // Mostrar mensaje de registro exitoso
                            Toast.makeText(IngresosRegister.this, "Ingreso registrado", Toast.LENGTH_SHORT).show();
                        } else {
                            // Mostrar mensaje de error genérico en caso de falla
                            Toast.makeText(IngresosRegister.this, "No se pudo registrar el ingreso", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<IngresoRegister> call, Throwable t) {
                        // Mostrar mensaje de fallo en la conexión
                        Toast.makeText(IngresosRegister.this, "Fallo en la conexión: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        // Manejar el clic en el botón de cancelar
        Button buttonCancelar = findViewById(R.id.buttonCancelar);
        buttonCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Limpiar los campos al hacer clic en el botón de cancelar
                clearFields(findViewById(R.id.id_id), findViewById(R.id.id_usuario_id), findViewById(R.id.id_categoria_id), findViewById(R.id.id_titulo), findViewById(R.id.id_cantidad), findViewById(R.id.id_fecha), findViewById(R.id.id_hora), findViewById(R.id.id_motivo), findViewById(R.id.id_tipoingreso), findViewById(R.id.id_notas));
            }
        });
    }

    // Método para limpiar los EditText
    private void clearFields(EditText... fields) {
        for (EditText field : fields) {
            field.getText().clear();
        }
    }
}
