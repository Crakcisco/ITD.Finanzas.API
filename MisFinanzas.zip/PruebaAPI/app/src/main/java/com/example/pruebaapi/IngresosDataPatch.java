package com.example.pruebaapi;

// IngresosDataPatch.java
public class IngresosDataPatch {
    private String type;
    private IngresosAttributesPatch attributes;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public IngresosAttributesPatch getAttributes() {
        return attributes;
    }

    public void setAttributes(IngresosAttributesPatch attributes) {
        this.attributes = attributes;
    }
}
