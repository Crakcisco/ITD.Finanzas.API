package com.example.pruebaapi;

import com.example.pruebaapi.RequestIngresosPatchData;

public class RequestIngresosPatch {
    private RequestIngresosPatchData data;

    public RequestIngresosPatchData getData() {
        return data;
    }

    public void setData(RequestIngresosPatchData data) {
        this.data = data;
    }
}
