package com.example.pruebaapi;

public class RequestIngresos {
    private RequestIngresosData data;

    public RequestIngresos(RequestIngresosData data) {
        this.data = data;
    }

    public RequestIngresosData getData() {
        return data;
    }

    public void setData(RequestIngresosData data) {
        this.data = data;
    }
}

