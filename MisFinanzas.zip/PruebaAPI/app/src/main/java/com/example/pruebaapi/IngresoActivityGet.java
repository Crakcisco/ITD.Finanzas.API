package com.example.pruebaapi;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class IngresoActivityGet extends AppCompatActivity {

    private RecyclerView recyclerView;
    private IngresosAdapter ingresosAdapter;
    private ApiIngresoGet apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingresos);

        // Configuración de Retrofit
        //apiService = RetrofitClient.getRetrofitInstance().create(ApiIngresoGet.class);

        recyclerView = findViewById(R.id.recyclerViewIngresos);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Llamada a la API para obtener ingresos
        Call<List<IngresoResponse>> call = apiService.getIngresos();
        call.enqueue(new Callback<List<IngresoResponse>>() {
            @Override
            public void onResponse(Call<List<IngresoResponse>> call, Response<List<IngresoResponse>> response) {
                if (response.isSuccessful()) {
                    List<IngresoResponse> ingresoResponseList = response.body();
                    if (ingresoResponseList != null && !ingresoResponseList.isEmpty()) {
                        List<IngresoDto> ingresosDtoList = new ArrayList<>();
                        for (IngresoResponse ingresoResponse : ingresoResponseList) {
                            List<IngresoResponse.IngresoData> ingresoDataList = ingresoResponse.getData();
                            if (ingresoDataList != null && !ingresoDataList.isEmpty()) {
                                for (IngresoResponse.IngresoData ingresoData : ingresoDataList) {
                                    IngresoDto ingresoDto = ingresoData.getAttributes();
                                    ingresosDtoList.add(ingresoDto);
                                }
                            }
                        }
                        ingresosAdapter = new IngresosAdapter(ingresosDtoList);
                        recyclerView.setAdapter(ingresosAdapter);
                    } else {
                        Toast.makeText(IngresoActivityGet.this, "La lista de ingresos está vacía", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(IngresoActivityGet.this, "Error al obtener ingresos", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<IngresoResponse>> call, Throwable t) {
                Toast.makeText(IngresoActivityGet.this, "Error de red", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
