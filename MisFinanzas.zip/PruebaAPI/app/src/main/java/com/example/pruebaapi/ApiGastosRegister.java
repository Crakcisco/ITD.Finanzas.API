package com.example.pruebaapi;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiGastosRegister {
    @POST("Gastos/Post") // Cambia esta URL al endpoint correcto para el registro de gastos
    Call<GastoRegister> registerGasto(@Body RequestGastos requestGastos);
}
