package com.example.pruebaapi;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private ApiService apiService;
    private EditText editTextId, editTextTitulo, editTextCantidad, editTextFecha, editTextHora, editTextMotivo, editTextNotas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activitymain);

        // Initialize Retrofit
        apiService = RetrofitClient.getClient("http://10.0.2.2:5207/api/").create(ApiService.class);

        // Initialize EditTexts
        editTextId = findViewById(R.id.editTextId);
        editTextTitulo = findViewById(R.id.editTextTitulo);
        editTextCantidad = findViewById(R.id.editTextCantidad);
        editTextFecha = findViewById(R.id.editTextFecha);
        editTextHora = findViewById(R.id.editTextHora);
        editTextMotivo = findViewById(R.id.editTextMotivo);
        editTextNotas = findViewById(R.id.editTextNotas);
    }

    public void onActualizarClick(View view) {
        // Validate input fields
        if (validateFields()) {
            // Create the patch request
            RequestIngresosPatchData data = new RequestIngresosPatchData();
            data.setId(Integer.parseInt(editTextId.getText().toString())); // ID of the record to update
            data.setTitulo(editTextTitulo.getText().toString());
            data.setCantidad(Float.parseFloat(editTextCantidad.getText().toString()));
            data.setFecha(editTextFecha.getText().toString());
            data.setHora(editTextHora.getText().toString());
            data.setMotivo(editTextMotivo.getText().toString());
            data.setNotas(editTextNotas.getText().toString());

            RequestIngresosPatch patchRequest = new RequestIngresosPatch();
            patchRequest.setData(data);

            // Make the PATCH request
            apiService.patchIngresos(patchRequest).enqueue(new Callback<IngresosResponsePatch>() {
                @Override
                public void onResponse(Call<IngresosResponsePatch> call, Response<IngresosResponsePatch> response) {
                    if (response.isSuccessful()) {
                        Toast.makeText(MainActivity.this, "Actualización exitosa", Toast.LENGTH_SHORT).show();
                        clearFields();
                    } else {
                        Toast.makeText(MainActivity.this, "Error en la actualización", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<IngresosResponsePatch> call, Throwable t) {
                    Toast.makeText(MainActivity.this, "Error de conexión", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Toast.makeText(MainActivity.this, "Por favor llene todos los campos", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean validateFields() {
        return !TextUtils.isEmpty(editTextId.getText().toString().trim()) &&
                !TextUtils.isEmpty(editTextTitulo.getText().toString().trim()) &&
                !TextUtils.isEmpty(editTextCantidad.getText().toString().trim()) &&
                !TextUtils.isEmpty(editTextFecha.getText().toString().trim()) &&
                !TextUtils.isEmpty(editTextHora.getText().toString().trim()) &&
                !TextUtils.isEmpty(editTextMotivo.getText().toString().trim()) &&
                !TextUtils.isEmpty(editTextNotas.getText().toString().trim());
    }

    private void clearFields() {
        editTextId.setText("");
        editTextTitulo.setText("");
        editTextCantidad.setText("");
        editTextFecha.setText("");
        editTextHora.setText("");
        editTextMotivo.setText("");
        editTextNotas.setText("");
    }
}
