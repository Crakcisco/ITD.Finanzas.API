package com.example.pruebaapi;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;

public class InicioActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private ActionBarDrawerToggle toggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_main); // Infla el diseño de la actividad

        // Configura la barra de herramientas
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.menu); // Establece el icono del menú de hamburguesa

        // Configura el DrawerLayout y ActionBarDrawerToggle
        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Configura el NavigationView
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (toggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Manejar los clics en los elementos del menú
        int id = item.getItemId();

        if (id == R.id.nav_nuevo_ingreso) {
            // Cuando se selecciona "Nuevo Ingresos"
            Intent intent = new Intent(InicioActivity.this, IngresosRegister.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.nav_nuevo_gasto) {
            // Cuando se selecciona "Nuevo Gasto"
            Intent intent = new Intent(InicioActivity.this, GastosRegister.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.nav_usuarios) {
            // Cuando se selecciona "Usuarios"
            Intent intent = new Intent(InicioActivity.this, UsuarioActivityGet.class);
            startActivity(intent);
            return true;

        }
        else if (id == R.id.nav_update_ingreso) {
            //Cuando se selecciona "Actualizar Ingreso"
           Intent intent = new Intent(InicioActivity.this, MainActivity.class);
           startActivity(intent);
            return true;

        //}
        //else if (id == R.id.nav_get_ingresos) {
            // Cuando se selecciona "Usuarios"
            //  Intent intent = new Intent(InicioActivity.this, IngresoActivityGet.class);
            //startActivity(intent);
            //1return true;

        } else if (id == R.id.nav_cerrar_sesion) {
            // Cuando se selecciona "Cerrar Sesión"
            // Aquí puedes implementar el código para cerrar sesión
            // y redirigir a LoginActivity
            Intent intent = new Intent(InicioActivity.this, LoginActivity.class);
            startActivity(intent);
            finish(); // Esto cierra la actividad actual
            return true;
        }

        // Si se selecciona otro elemento del menú, cierra el DrawerLayout
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawers();
        return true;
    }
}


