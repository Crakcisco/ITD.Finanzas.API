package com.example.pruebaapi;


import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.PATCH;
import retrofit2.http.Path;

public interface ApiService {
    @PATCH("Ingresos/Patch")
    Call<IngresosResponsePatch> patchIngresos(@Body RequestIngresosPatch patchRequest);
}
