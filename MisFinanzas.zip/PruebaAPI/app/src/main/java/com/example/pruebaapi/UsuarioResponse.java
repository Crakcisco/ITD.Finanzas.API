package com.example.pruebaapi;

public class UsuarioResponse {
    public UsuarioData data;

    public UsuarioData getData() {
        return data;
    }

    public void setData(UsuarioData data) {
        this.data = data;
    }
}
