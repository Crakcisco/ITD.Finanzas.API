package com.example.pruebaapi;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class GastosActivity extends AppCompatActivity {

    private ListView listViewGastos;
    private List<String> listaGastos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gastos);

        // Inicializar la lista de gastos
        listaGastos = new ArrayList<>();
        listaGastos.add("Gasto 1");
        listaGastos.add("Gasto 2");
        listaGastos.add("Gasto 3");

        // Configurar el ListView
        listViewGastos = findViewById(R.id.listViewGastos);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaGastos);
        listViewGastos.setAdapter(adapter);

        // Manejar clics en elementos de la lista (para modificar gastos)
        listViewGastos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String gastoSeleccionado = listaGastos.get(position);
                // Aquí puedes implementar la lógica para modificar el gasto seleccionado
                Toast.makeText(GastosActivity.this, "Gasto seleccionado: " + gastoSeleccionado, Toast.LENGTH_SHORT).show();
            }
        });

        // Manejar clic en botón para agregar gasto
        Button btnAgregarGasto = findViewById(R.id.btnAgregarGasto);
        btnAgregarGasto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Aquí puedes implementar la lógica para agregar un nuevo gasto
                Toast.makeText(GastosActivity.this, "Agregar nuevo gasto", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
