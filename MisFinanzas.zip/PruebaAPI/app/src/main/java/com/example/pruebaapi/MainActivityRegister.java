package com.example.pruebaapi;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivityRegister extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button id_button = findViewById(R.id.id_button);
        id_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText edt_id = findViewById(R.id.id_id);
                EditText edt_nombre = findViewById(R.id.id_nombre);
                EditText edt_email = findViewById(R.id.id_email);
                EditText edt_password = findViewById(R.id.id_password);

                int id = Integer.parseInt(edt_id.getText().toString().trim());
                String nombre = edt_nombre.getText().toString().trim();
                String email = edt_email.getText().toString().trim();
                String password = edt_password.getText().toString().trim();

                if (nombre.isEmpty() || email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivityRegister.this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
                logging.setLevel(HttpLoggingInterceptor.Level.BODY);

                OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
                httpClient.addInterceptor(logging);

                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("http://10.0.2.2:5207/api/")
                        .addConverterFactory(GsonConverterFactory.create())
                        .client(httpClient.build())
                        .build();

                ApiUserRegister apiUser = retrofit.create(ApiUserRegister.class);

                RequestUsuarioData requestUsuarioData = new RequestUsuarioData(id, nombre, email, password);
                RequestUsuario requestUsuario = new RequestUsuario(requestUsuarioData);

                Call<UserRegister> call = apiUser.registerUser(requestUsuario);

                call.enqueue(new Callback<UserRegister>() {
                    @Override
                    public void onResponse(Call<UserRegister> call, Response<UserRegister> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            edt_id.getText().clear();
                            edt_nombre.getText().clear();
                            edt_email.getText().clear();
                            edt_password.getText().clear();
                            String token = response.body().getToken();

                            Intent intent = new Intent(MainActivityRegister.this, Logueado.class);
                            intent.putExtra("token", token);
                            startActivity(intent);
                        } else {
                            Toast.makeText(MainActivityRegister.this, "Error en la respuesta del servidor", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<UserRegister> call, Throwable t) {
                        Toast.makeText(MainActivityRegister.this, "Fallo en la conexión", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        // Manejar el clic en el botón de iniciar sesión
        Button loginButton = findViewById(R.id.id_login_button);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivityRegister.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}

