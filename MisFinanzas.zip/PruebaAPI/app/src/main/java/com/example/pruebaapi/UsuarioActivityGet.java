package com.example.pruebaapi;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pruebaapi.ui.theme.RetrofitClient;

import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UsuarioActivityGet extends AppCompatActivity {

    private RecyclerView recyclerView;
    private UsuariosAdapter usuariosAdapter;
    private ApiUsuarioGet apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuarios);

        // Configuración de Retrofit
        apiService = RetrofitClient.getRetrofitInstance().create(ApiUsuarioGet.class);

        recyclerView = findViewById(R.id.recyclerViewUsuarios);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Llamada a la API para obtener usuarios
        Call<List<UsuarioResponse>> call = apiService.getUsuarios();
        call.enqueue(new Callback<List<UsuarioResponse>>() {
            @Override
            public void onResponse(Call<List<UsuarioResponse>> call, Response<List<UsuarioResponse>> response) {
                if (response.isSuccessful()) {
                    List<UsuarioResponse> usuariosResponse = response.body();
                    List<UsuarioDto> UsuarioDto = usuariosResponse.get(0).data.attributes;
                    // Crear y establecer el adaptador para el RecyclerView
                    usuariosAdapter = new UsuariosAdapter(UsuarioDto);
                    recyclerView.setAdapter(usuariosAdapter);
                } else {
                    Toast.makeText(UsuarioActivityGet.this, "Error al obtener usuarios", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<UsuarioResponse>> call, Throwable t) {
                Toast.makeText(UsuarioActivityGet.this, "Error de red", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
