package com.example.pruebaapi;

public class RequestIngresosData {
    private int id;
    private int usuario_id;
    private int categoria_id;
    private String titulo;
    private String cantidad;
    private String fecha;
    private String hora;
    private String motivo;
    private String tipo_ingreso;
    private String notas;

    public RequestIngresosData(int id, int usuario_id, int categoria_id, String titulo, String cantidad, String fecha, String hora, String motivo, String tipo_ingreso, String notas) {
        this.id = id;
        this.usuario_id = usuario_id;
        this.categoria_id = categoria_id;
        this.titulo = titulo;
        this.cantidad = cantidad;
        this.fecha = fecha;
        this.hora = hora;
        this.motivo = motivo;
        this.tipo_ingreso = tipo_ingreso;
        this.notas = notas;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUsuario_id() {
        return usuario_id;
    }

    public void setUsuario_id(int usuario_id) {
        this.usuario_id = usuario_id;
    }

    public int getCategoria_id() {
        return categoria_id;
    }

    public void setCategoria_id(int categoria_id) {
        this.categoria_id = categoria_id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getTipoGasto() {
        return tipo_ingreso;
    }

    public void setTipoGasto(String tipoGasto) {
        this.tipo_ingreso = tipoGasto;
    }

    public String getNotas() {
        return notas;
    }

    public void setNotas(String notas) {
        this.notas = notas;
    }
}

