package com.example.pruebaapi;

import com.google.gson.annotations.SerializedName;

public class LoginResponse {
    @SerializedName("token")
    private String token;

    @SerializedName("userId")
    private int userId; // Nuevo campo para el ID del usuario

    public String getToken() {
        return token;
    }

    public int getUserId() {
        return userId;
    }
}


