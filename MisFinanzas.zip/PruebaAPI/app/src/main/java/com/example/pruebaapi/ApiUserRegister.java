package com.example.pruebaapi;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiUserRegister {
    @POST("Usuarios/Post") // Cambia esta URL al endpoint correcto para el registro
    Call<UserRegister> registerUser(@Body RequestUsuario user);
}
