package com.example.pruebaapi;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiUsuarioGet {
    @GET("Usuarios/Get") // Reemplaza con la ruta correcta de tu endpoint
    Call<List<UsuarioResponse>> getUsuarios();
}