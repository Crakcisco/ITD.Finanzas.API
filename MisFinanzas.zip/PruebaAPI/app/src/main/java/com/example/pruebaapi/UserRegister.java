package com.example.pruebaapi;

public class UserRegister {
    private int userId; // Nuevo campo para almacenar el ID del usuario creado
    private RequestUsuario data;
    private String token;

    public UserRegister(int userId, RequestUsuario data, String token) {
        this.userId = userId;
        this.data = data;
        this.token = token;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public RequestUsuario getData() {
        return data;
    }

    public void setData(RequestUsuario data) {
        this.data = data;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
