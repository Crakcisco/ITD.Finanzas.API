package com.example.pruebaapi;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class IngresoResponse {
    @SerializedName("data")
    private List<IngresoData> data;

    public List<IngresoData> getData() {
        return data;
    }

    public class IngresoData {
        @SerializedName("attributes")
        private IngresoDto attributes;

        public IngresoDto getAttributes() {
            return attributes;
        }
    }
}
