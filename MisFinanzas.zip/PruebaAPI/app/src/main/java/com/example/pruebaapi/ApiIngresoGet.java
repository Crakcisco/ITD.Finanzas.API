package com.example.pruebaapi;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiIngresoGet {
    @GET("Ingresos/Get")
    Call<List<IngresoResponse>> getIngresos();
}
