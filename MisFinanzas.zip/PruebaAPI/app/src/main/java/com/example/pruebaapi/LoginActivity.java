package com.example.pruebaapi;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextEmail, editTextPassword;
    private ApiUserLogin apiUserLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextEmail = findViewById(R.id.id_email);
        editTextPassword = findViewById(R.id.id_password);
        Button buttonLogin = findViewById(R.id.id_login_button);
        Button buttonRegister = findViewById(R.id.id_register_button); // Botón de registrarse

        // Configuración de Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.0.2.2:5207/api/") // Cambia esta URL según tu endpoint
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        // Crear instancia de la interfaz ApiUserLogin
        apiUserLogin = retrofit.create(ApiUserLogin.class);

        buttonLogin.setOnClickListener(v -> {
            String email = editTextEmail.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            // Verificar si los campos están vacíos
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            // Crear objeto LoginRequest con los datos del usuario
            LoginRequest loginRequest = new LoginRequest(email, password);

            // Realizar llamada a la API para el inicio de sesión
            Call<LoginResponse> call = apiUserLogin.login(loginRequest);
            call.enqueue(new Callback<LoginResponse>() {
                @Override
                public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        String token = response.body().getToken();
                        int userId = response.body().getUserId(); // Obtener el ID del usuario
                        // Guardar el ID del usuario en SharedPreferences u otro lugar de almacenamiento
                        guardarIdUsuario(userId);
                        // Iniciar otra actividad si las credenciales son válidas
                        Intent intent = new Intent(LoginActivity.this, InicioActivity.class); // Cambia Logueado.class a InicioActivity.class
                        intent.putExtra("token", token);
                        startActivity(intent);
                        finish(); // Esto finaliza la actividad actual (LoginActivity)
                    } else {
                        Toast.makeText(LoginActivity.this, "Credenciales incorrectas", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<LoginResponse> call, Throwable t) {
                    Toast.makeText(LoginActivity.this, "Fallo en la conexión", Toast.LENGTH_SHORT).show();
                }
            });
        });

        // Manejar el clic en el botón de registrarse
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, MainActivityRegister.class);
                startActivity(intent);
            }
        });
    }

    // Método para guardar el ID del usuario en SharedPreferences u otro lugar de almacenamiento
    private void guardarIdUsuario(int userId) {
        SharedPreferences sharedPreferences = getSharedPreferences("usuario", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("userId", userId);
        editor.apply();
    }
}
