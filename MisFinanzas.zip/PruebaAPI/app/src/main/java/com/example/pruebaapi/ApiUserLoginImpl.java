package com.example.pruebaapi;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;

public class ApiUserLoginImpl implements ApiUserLogin {
    private static final String BASE_URL = "http://10.0.2.2:5207/api/";
    private Retrofit retrofit;

    public ApiUserLoginImpl() {
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }

    @Override
    public  Call<LoginResponse> login (@Body LoginRequest loginRequest) {
        ApiUserLogin apiUserLogin = retrofit.create(ApiUserLogin.class);
        return apiUserLogin.login(loginRequest);
    }
}
