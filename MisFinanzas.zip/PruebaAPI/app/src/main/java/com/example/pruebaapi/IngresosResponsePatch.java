package com.example.pruebaapi;

// IngresosResponsePatch.java
public class IngresosResponsePatch {
    private IngresosDataPatch data;

    // Getters y setters
    public IngresosDataPatch getData() {
        return data;
    }

    public void setData(IngresosDataPatch data) {
        this.data = data;
    }
}
