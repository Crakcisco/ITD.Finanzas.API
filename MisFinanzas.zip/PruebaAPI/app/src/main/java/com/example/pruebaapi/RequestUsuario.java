package com.example.pruebaapi;

public class RequestUsuario {
    private RequestUsuarioData data;

    public RequestUsuario(RequestUsuarioData data) {
        this.data = data;
    }

    public RequestUsuarioData getData() {
        return data;
    }

    public void setData(RequestUsuarioData data) {
        this.data = data;
    }


}

