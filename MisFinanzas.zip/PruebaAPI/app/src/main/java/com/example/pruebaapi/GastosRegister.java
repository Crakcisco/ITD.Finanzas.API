package com.example.pruebaapi;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class GastosRegister extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nuevo_gasto);

        Button buttonAgregar = findViewById(R.id.buttonAgregar);
        buttonAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener referencias a los EditText
                EditText edtId = findViewById(R.id.id_id);
                EditText edtUsuarioId = findViewById(R.id.id_usuario_id);
                EditText edtCategoriaId = findViewById(R.id.id_categoria_id);
                EditText edtTitulo = findViewById(R.id.id_titulo);
                EditText edtCantidad = findViewById(R.id.id_cantidad);
                EditText edtFecha = findViewById(R.id.id_fecha);
                EditText edtHora = findViewById(R.id.id_hora);
                EditText edtMotivo = findViewById(R.id.id_motivo);
                EditText edtTipoGasto = findViewById(R.id.id_tipogasto);
                EditText edtNotas = findViewById(R.id.id_notas);

                // Obtener los valores de los EditText
                int id = Integer.parseInt(edtId.getText().toString().trim());
                int usuario_id = Integer.parseInt(edtUsuarioId.getText().toString().trim());
                int categoria_id = Integer.parseInt(edtCategoriaId.getText().toString().trim());
                String titulo = edtTitulo.getText().toString().trim();
                String cantidad = edtCantidad.getText().toString().trim();
                String fecha = edtFecha.getText().toString().trim();
                String hora = edtHora.getText().toString().trim();
                String motivo = edtMotivo.getText().toString().trim();
                String tipo_gasto = edtTipoGasto.getText().toString().trim();
                String notas = edtNotas.getText().toString().trim();

                // Validar que los campos no estén vacíos
                if (titulo.isEmpty() || cantidad.isEmpty() || fecha.isEmpty() || hora.isEmpty() || motivo.isEmpty() || tipo_gasto.isEmpty() || notas.isEmpty()) {
                    Toast.makeText(GastosRegister.this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Limpiar los campos después de validar que no estén vacíos
                clearFields(edtId, edtUsuarioId, edtCategoriaId, edtTitulo, edtCantidad, edtFecha, edtHora, edtMotivo, edtTipoGasto, edtNotas);

                // Configurar el interceptor de logging
                HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
                logging.setLevel(HttpLoggingInterceptor.Level.BODY);

                // Configurar el cliente OkHttpClient
                OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
                httpClient.addInterceptor(logging);

                // Configurar Retrofit
                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("http://10.0.2.2:5207/api/")
                        .addConverterFactory(GsonConverterFactory.create())
                        .client(httpClient.build())
                        .build();

                // Crear la instancia de la interfaz de servicio
                ApiGastosRegister apiGastos = retrofit.create(ApiGastosRegister.class);

                // Crear el objeto de datos de la solicitud
                RequestGastosData requestGastosData = new RequestGastosData(id, usuario_id, categoria_id, titulo, cantidad, fecha, hora, motivo, tipo_gasto, notas);
                RequestGastos requestGastos = new RequestGastos(requestGastosData);

                // Realizar la llamada asíncrona a la API
                Call<GastoRegister> call = apiGastos.registerGasto(requestGastos);

                // Manejar la respuesta de la llamada asíncrona
                call.enqueue(new Callback<GastoRegister>() {
                    @Override
                    public void onResponse(Call<GastoRegister> call, Response<GastoRegister> response) {
                        if (response.isSuccessful() && response.body()!=null) {
                            // Mostrar mensaje de registro exitoso
                            Toast.makeText(GastosRegister.this, "Gasto registrado", Toast.LENGTH_SHORT).show();


                        } else {
                            // Mostrar mensaje de error en caso de respuesta no exitosa
                            // Esto se puede omitir si no quieres mostrar el mensaje de error
                            // Toast.makeText(GastosRegister.this, "Error en la respuesta del servidor", Toast.LENGTH_SHORT).show();
                        Toast.makeText(GastosRegister.this, "No se pudo registrar", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<GastoRegister> call, Throwable t) {
                        // No mostrar mensaje de fallo en la conexión
                         //Toast.makeText(GastosRegister.this, "Fallo en la conexión: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        // Manejar el clic en el botón de cancelar
        Button buttonCancelar = findViewById(R.id.buttonCancelar);
        buttonCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Limpiar los campos al hacer clic en el botón de cancelar
                clearFields(findViewById(R.id.id_id), findViewById(R.id.id_usuario_id), findViewById(R.id.id_categoria_id), findViewById(R.id.id_titulo), findViewById(R.id.id_cantidad), findViewById(R.id.id_fecha), findViewById(R.id.id_hora), findViewById(R.id.id_motivo), findViewById(R.id.id_tipogasto), findViewById(R.id.id_notas));
            }
        });
    }

    // Método para limpiar los EditText
    private void clearFields(EditText... fields) {
        for (EditText field : fields) {
            field.getText().clear();
        }
    }
}

