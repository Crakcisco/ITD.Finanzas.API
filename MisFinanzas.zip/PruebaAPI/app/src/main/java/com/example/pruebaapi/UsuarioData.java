package com.example.pruebaapi;

import java.util.List;

public class UsuarioData {
    public List<UsuarioDto> attributes;
    private String type;

    public List<UsuarioDto> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<UsuarioDto> attributes) {
        this.attributes = attributes;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
